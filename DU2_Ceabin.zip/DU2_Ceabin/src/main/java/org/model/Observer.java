package org.model;

public interface Observer {
    void notification(Post post);
}

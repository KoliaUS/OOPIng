package org.model;

public interface Observable {
    void addFollow(User user);
}

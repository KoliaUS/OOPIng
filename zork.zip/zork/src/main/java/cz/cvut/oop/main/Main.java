package cz.cvut.oop.main;

import cz.cvut.oop.ui.CommandLineUi;

public class Main {

    public static void main(String[] args){
        CommandLineUi.getInstance().start();
    }

}

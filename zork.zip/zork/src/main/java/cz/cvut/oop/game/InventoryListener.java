package cz.cvut.oop.game;

import java.util.ArrayList;
import java.util.List;

public interface InventoryListener {
     void printFullInventory(ArrayList<Item> items);
}

